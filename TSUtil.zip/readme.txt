
Installation des Java-Programms "TSUtil" :

 - Java-Runtime-Umgebung suchen (meist in "programme\javasoft\jre\<version>" )
 - Zus�tzlich zu den Verzeichnissen "lib" und "bin" ein Verzeichnis
	"classes" erzeugen falls noch nicht vorhanden
 - Die '.class' - Dateien (TSUtil.class, TSShape.class,...) in das Verzeichnis kopieren
 - Die '.properties' - Dateien (TSErrMsg_de.properties,...) in das Verzeichnis kopieren

 - Folgende Datei(en) aus dem Verzeichnis l�schen falls vorhanden:
	+ TSErrMsg_en.properties


Pr�fen ob Datei gefunden:
 - Dos-Eingabeumgebung �ffen
 - "Java TSUtil" (Gross/Kleinschreibung!) eingeben
Wenn das Programm gefunden wird erfolgt die Ausgabe:
	"Fehler - Zu wenig Argumente!"
sowie weitere Zeilen.


Ab sofort ist eine jar-Datei verf�gbar, die alternativ oder zus�tzlich benutzt werden kann:

Installation:
  - Die Datei "TSUtil.jar" in ein beliebiges Verzeichnis kopieren/entpacken.

Funktionspr�fung:
 - Dos-Eingabeumgebung �ffen
 - das Verzeichnis mit der jar-Datei aktivieren (aktuelles Verzeichnis) 
 - "Java -jar TSUtil.jar" (Gross/Kleinschreibung!) eingeben
Wenn das Programm erfolgreich aktiviert wird erfolgt die Ausgabe:
	"Fehler - Zu wenig Argumente!"
sowie weitere Zeilen.

ACHTUNG:
Mit der Installation dieses Programms AKZEPTIEREN Sie ausdruecklich die Nutzungsvereinbarung am Ende
des Dokumentes "TSUtil_de.txt", das dieser Zip-Datei beigef�gt ist. Falls Sie damit NICHT einverstanden
sind, ist die Installation dieses Programms  - oder eines Teiles davon - nicht erlaubt.

carlos (carlosHR@t-online.de)


Zur Handhabung von TSUtil bitte auch Datei "TSUtil_de.txt" lesen!

*************************************************************************************************

Installation of Program "TSUtil" :

 - Search for the Java-Runtime-Environment (e.g.  "program files\javasoft\jre\<version>" )
 - Locate the directory where the directories  "lib" and "bin" are present.
 - Create a new directory and name it "classes" if it is not already there.
 - Copy all '.class' - files (TSUtil.class, TSShape.class,...) into the (new) directory
 - Copy all '.properties' - files (TSErrMsg_de.properties,...) into the (new) directory

 - Delete the following files from the directory if present:
	+ TSErrMsg_en.properties


To check the availability of the Utility:
 - Open a Dos-Window
 - Enter: "Java TSUtil" (pay attention to case of letters)
If the Utility can be activated you will see the Message:
	"Error -- Too less arguments!"
followed by other lines.

You can also use the attached jar-File to get the functions:
Installation:
 - copy or decompress the file "TSUtil.jar" into an arbitrary directory

Check of availiability:
 - Open a Dos-Window
 - Branch to the directory where the jar-file is located
 - Enter: "Java -jar TSUtil.jar" (pay attention to case of letters)
If the Programm can be activated successfully you will see the Message:
	"Error -- Too less arguments!"
followed by other lines.

ATTENTION:
When you install this programm, you expressly accept the user-license-agreement at the end of
"TSUtil_en.txt", which is attached to this file. If you do NOT accept this ageement you must not
install this program or a part of it.
 
carlos (carlosHR@t-online.de)


A brief description of the utility is located in file "TSUtil_en.txt"!

