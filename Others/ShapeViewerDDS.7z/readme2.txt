SView 2.2.237 - 27th March 2008
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
� 2004-2008 Paul Gausden


****************************************************************
**************                                       ***********
************** UNINSTALL ANY PREVIOUS VERSIONS FIRST ***********
**************                                       ***********
****************************************************************


Double click on the SView22.msi file to install this software.

Version 2.2 - April 2008
~~~~~~~~~~~~~~~~~~~~~~~~
Fix - no zero byte files created if the file referenced by con or wag file does not exist. 
Fix - Quotes now allowed in CON/WAG/ENG file & folder names. 
Fix - Improved IM file support (fewer crashes).
Fix - Adjusted animation rate dependant on FPS in model.
Fix - Stuck in loop if opened second shape with hierarchy display. 
Fix - Installer now includes dx8vb.dll for vista users.  
Added - Finer control over camera position with Ctrl+Shift keys
Added - Reload WAG/ENG with Ctrl+F5 key


Version 2.1.225 - 21st Sept 2007
~~~~~~~~~~~~~~~
- Support for more shaders and sub objects used by MSTS (Diffuse, GlossMap etc) - Sketchup MSTS models without - textures and "fixed" models should all display correctly. 
- Fixed - Screenshot location now removes the .screenshot from the filename after a change. 
- Fixed - models with textures of 16x16 or less failed to load. 
- Fixed - hierarchy display now shows correct shader name.
- Ability to load complex bounding boxes from MSTS SD files. 
- Can now Open MSTS ENG and WAG files, including freight anims. 
- Can now open MSTS Consist files (.CON) 
- Some support for loading Trainz (TRS) models (config.txt) and meshes (.IM files) 
- Some Multi-Monitor support. 
- Reduced CPU usage (to almost zero) 
- Position displays for some items - lights, smoke, attachments etc 
- Camera field of view adjustment  
- Current Directory file list and scroll (Alt + Up or Down arrow)
- fixed loading of files containing extended ascii characters such as �
- build 225 - few bug fixes added to 2.1.222, alpha sorting, quotes around file names and window ordering.



Version 1.6.187 - 14th Nov 2005
~~~~~~~~~~~~~~~
	Patch to build 181, fixes european wire height problems, triggered and reversed animations have been corrected.
	Environment mapping for MSTS models can be enabled for materials marked as HiShine or LoShine.


Version 1.5.181
~~~~~~~~~~~~~~~
	Overhead Wire display.
	Save textures as TGA or BMP.
	Screenshot can now be a fixed file name or a prefix.
	AppPath and AppVersion now stored in the registry.
	Triggerable animations - Pantographs , Wipers (Doors and Mirrors too)
	Bogie wheels animate correctly
	Model Matrix/vertex state/primitive hierarchy viewer with highlighting option
	With the Main tab selected, pressing Num-lock shows the camera position.


Version 1.4.158 - 4th Jan 2005, bug fixes to builds 151 and 155
~~~~~~~~~~~~~~~
	Now installs properly on Win98/ME
	Orthogonal Projection view (Tools/Orthogonal Ctrl-P)
	4 View screenshot (Tools Menu)
	8 frame animated screenshot (Tools Menu)
	Camera positioning menu option front/back/left/right/60 degrees left/right (tools menu)
	Reads simple bounding box info from .sd file
	Load Second shape is now functions as an "Add" shape.
	trainlib OCX now installed into windows\system folder.


Version 1.3a 24th May 2004
~~~~~~~~~~~
	Improved frame rates
	Spanish version now looks for sview_es.chm, not sview_fr.chm
	Sun in the sky
	180 flip for main model
	more bounding box info from the edit menu.
	Corrected screenshot location bug


Version 1.2 May 2004
~~~~~~~~~~~
	Bugs fixed for loading objects and others 
	Screenshot option to save as JPG 
	Model bounding box and Size display on Ctrl-B or Edit Menu (not the same as SD file) 
	Low Quality Texture display (same as MSTS) Ctrl-L or Edit Menu 
	Language translations corrected 
	If the PC is set for German, Spanish or French language, the program will look for help text files sview_de.chm, sview_es.chm or sview_fr.chm. These do not exist, but should anyone wish to write them they can be distributed seperately. 
	Put back object rotation onto the animation tab 


Version 1.1 Feb 2004
~~~~~~~~~~~
	New option to change sky texture, plus samples.
	Synchronised Sky menu with options
	New option to set screenshot folder and prefix
	fixed rotated bogie animations
	Adjusted texture lighting effects
	open file after using file association to start uses current folder.
	Time and latitude for "Sun"
	10 saveable camera positions Ctrl+Number saves, Number to restore
	Fixed non-identity main matrix bug
	More countries will be able to see localized menus/captions
	Seasonal textures
	Display base option by Tim Court
	Ctrl Key and Mouse movement control to control view point.


Version 1.0 22 Jan 2004
~~~~~~~~~~~
	Corrected display to support more models (gmax and odd sized textures)
	Corrected uncompressed read for european mode windows
	Grid and Grass options
	Texture info display and toggle
	Menu and Help Text
	LOD list and "efficiency" display.
	Full keyboard control via arrow keys
	Refresh/Reload on F5 key
	Line Drawing mode (Backspace key)
	Load, position and flip a second object into the scene
	Adjustable background colour and brightness
	Fog
	Anisotropic texture filter
	AntiAlias
	Animation
	Sky texture
	Right mouse button zoom
	


Beta 3/4 changes: Dec 2003
~~~~~~~~~~~~~~~~~
	Reads Uncompressed S files (slower than compressed files)
	F12 - Toggles full screen mode
	F11 - Screenshot shortcut
	Esc - Quit
	Numeric keypad + and - change the view distance
	Page up/down alter rotation speed
	Texturing correct (?) - specular, bright, dark etc
	Minimize window should no longer crash
	Transparencies Corrected
	Can be directly associated with S files
	Screenshot uses a continuous sequence, does not restart at 000

beta 4a - fixed TSM model translucency, SIS video card problems and form resize distortion
	

Beta 2 changes - 3rd Dec 2003
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
The main changes for this version are adjustments to the way the viewer operates.

- Hopefully there are some improvements with transparency handling.
- You may now associate S files with SVIEW.EXE
- Adjusting rotation speed is handled better
- Grey background can be changed from black through grey to white
- The mouse can be used to "drag" the camera - NOTE THE ROTATION APPLYS TO THE MODEL.
- Goldsdof 380 model now works.
- The screenshot now appears in the same folder as the program, not the S file
- fixes for some video cards (ATI, Intel)


The viewer will still not:

- show data from ENG files (lights, steam, smoke, freight anim etc)
