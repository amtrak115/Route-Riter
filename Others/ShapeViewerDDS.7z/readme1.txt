Shape Viewer DDS

In order to support ORST - Paul Gausden was kind enough to provide a new update to Shape Viewer so it can now read/display DDS files as well as ACE files. It's set in a similar fashion as ORST where it prefers DDS with a fallback to ACE. If you have both a DDS and ACE in the same directory - it will read/display the DDS until it's removed - then it will read/display the ACE. Uploaded with permission. Content by Paul Guasden - Packaged by Scott Brunner.

License: While provided as Freeware to the community - Paul Gausden retains all rights to the files included in this download.

Installation: The package includes two files - the latest version of Shape Viewer [SView22.msi] for those that may need it - and the updated file to read DDS files [trainlib.ocx]. 

For most - it should be a simple matter of simply copying [trainlib.ocx] into your current Shape Viewer directory - overwriting the original. That's it - enjoy.

For some - old versions of Route Riter or ConEditor may have installed parts of Shape Viewer in a different location - if after performing the above step - DDS files aren't being read/displayed - the easiest fix is to "Uninstall" Shape Viewer completely - then "Install" Shape Viewer again - then copy [trainlib.ocx] to your Shape Viewer directory overwriting the original.

Any issues - please contact me in the usual places.

Regards,
Scott