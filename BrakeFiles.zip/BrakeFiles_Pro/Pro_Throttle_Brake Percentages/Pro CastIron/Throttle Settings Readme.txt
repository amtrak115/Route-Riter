Make sure you enable "Wordwrap" in the "Format" dropdown menu in your Notepad or Wordpad applications so you don't have to scroll left and right to read this document.

This document contains Throttle percentages for various types of locomotives mirroring their RW counterparts in percentages of power applied to the wheels with each throttle position.  Also included are new max Engine Brake percentage values for both Freight and Passenger locomotives and Composition and Cast Iron Brake shoe equipped Freight and Passenger locomotives as well.  The max engine brake cylinder  pressure for composition brake shoe equipped units is 73psi.  The max engine brake cylinder  pressure for cast iron shoe equipped locomotives is 52psi.  These parameters are most effective in giving RW performance when used in conjunction with Bob Boudoion's Engine Physics and my V3.0 Pro and Novice coupler Packs and my V2.0 Brake packs for both Composition and Cast Iron Brake shoe equipped locomotives and rollingstock.  

Below you will find throttle and engine brake calibrations for most diesel locomotive types that can be found for MSTS.  There are both Composition Brake Shoe Equipped calibration files and Cast Iron Brake Shoe Equipped calibration files.  Only locomotive types that came originally equipped with Cast Iron Shoes are listed in the Cast Iron Shoe Equipped sections.  Raildriver owners will have to watch the percentage figures in the Throttle region of the F-5 display as the Throttle Notches in the RD throttle may not correspond with the percentage values.  Keyboard only end users will only have to keep track of actual throttle positions as each throttle up and down click of the keyboard will automatically use the new percentages.

MSTS has some quirks (now there's a big surprise) and it has been found that using different EngineBrakeControllerMaxSystemPressure and TrainBrakesControllerMaxSystemPressure values causes the Air Compressor to not disengage when the max main tank pressure is attained in some locomotives.  Using the correct max systems psi pressures for the engine brakes is one way to set your engines max brake cylinder pressure but you have the aforementioned bug.  So in order to get the correct Independant brake (Engine Brake) cylinder max pressure parameter for all the locomotives listed below it was necessary to change the value in the second line of the Brake_Engine controller line parameter.  In the sim your F-5 GUI Loco Brake percentage line values will top out at a less then the 100% value you are presently accustomed to.  When running in the incab view watch your Independant Brake Guage needle when using the engine brakes as it will now top out at the correct brake cylinder psi value.  In outside views watch the F-5 values as before, you will become accustomed to the new Loco brake  percentages with time.

Thanks to Bob Boudoin and J-L Chauvin and Joe Morris for allowing me to include some of their parameters in my work contained in this zip file.  Mike Simpson's payware version of Route Riter's eng/wag file editor can be used to make wholesale parameter changes to your EngineBrakesControllerMaxSystemPressure and TrainBrakeControllerMaxSystemPressure line values.  Just load and hilight the appropriate eng files you want to modify and use the editor to the left of the list to find the corresponding parameter lines you want to change.

Instructions:

Make sure your locomotive has the correct EngineBrakesControllerMaxSystemPressure and TrainBrakesControllerMaxSystemPressure values as stated in each of the locomotive's Calibration sections.  Copy and paste over the original EngineController and Brake_Engine regions with the new corrected ones for your particular locomotive model.  Include the "Comment" line so you can keep track of locomotives that you have modified.   

FIRST RENAME OR  MAKE BACKUPS OF ALL ORIGINAL ENG FILES YOU MODIFY!!!!!  

These files are most effective when used with the Bin Patch but will also work well on non Bin Patch equipped MSTS installations.  These parameters have been tested on my MSTS installation with the latest working release of the Bin Patch and found to work very well in mimicing these locomotives RW counterparts based on actual RW experiance running the various types included in this document.  I have run all the locomotive types listed below with the Baldwin's being the only exception.  My research shows that the Baldwin's were very similar to the ALCO locomotives in these areas.  I've run both the ALCO locomotive types listed below with cast iron brake shoes installed on the RW units.  I've run both the cast iron and composition brake shoe equipped versions of the EMD locomotives and the Composition brake shoe equipped GE units except for the GE switchers.  Since both builders used the same cast iron  brake shoes and max locomotive brake cylinder pressures, their engine braking performance is virtually the same with actual locomotive tonnages making the difference between the two builders  actual stopping distances.

These values are freeware.  If you do use these values in future locomotive or rollingstock releases please include this readme in your zip file to make sure all proper persons are given credit for their contributions.  As stated above these values worked as advertised on my MSTS installation using both the keyboard and the Raildriver to control your train.  Use at your own risk by perhaps doing one set of engines and raicars and seeing how they perform in your MSTS installation.  My computer did not blow up or melt down from using these parameters, I'm not responsible if your computer does.  I do hope you enjoy the new level of realism your rolllingstock will exhibit with these new values.

May all your signals be green and your Roll-by's black.

Turbo Bill 
aka Bill Prieger



FREIGHT LOCOMOTIVE CONTROLLER/BRAKE_ENGINE CALIBRATIONS (COMPOSITON BRAKE SHOE EQUIPPED)

EMD 567 80psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(80 )
	TrainBrakesControllerMaxSystemPressure( 80 )


     Comment ( EMD 567 Freight 80psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.91 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Road Switchers 80psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(80 )
	TrainBrakesControllerMaxSystemPressure( 80 )


     Comment ( ALCO/Baldwin Road Switchers 80psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.91 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )



EMD Switchers 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( EMD Switchers 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.085   0 Dummy )
                    Notch ( 0.155    0 Dummy )
                    Notch ( 0.260   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


EMD 567 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( EMD 567 Freight 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


EMD 645 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( EMD 645  Freight 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.045   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


EMD 710 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


      Comment ( EMD 710 Freight 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.063   0 Dummy )
                    Notch ( 0.120    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.340     0 Dummy )
                    Notch ( 0.453  0 Dummy )
                    Notch ( 0.700    0 Dummy )
                    Notch ( 0.860   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


 GE Switchers 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( GE Switchers 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.089   0 Dummy )
                    Notch ( 0.159    0 Dummy )
                    Notch ( 0.260   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


GE Dash-7 and down 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( GE Dash-7 and down Freight 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.044   0 Dummy )
                    Notch ( 0.114   0 Dummy )
                    Notch ( 0.231   0 Dummy )
                    Notch ( 0.351     0 Dummy )
                    Notch ( 0.511   0 Dummy )
                    Notch ( 0.657    0 Dummy )
                    Notch ( 0.827   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )



Dash-8 and up 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( GE Dash-8 and up Freight 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.058   0 Dummy )
                    Notch ( 0.118    0 Dummy )
                    Notch ( 0.265   0 Dummy )
                    Notch ( 0.376     0 Dummy )
                    Notch ( 0.535   0 Dummy )
                    Notch ( 0.686    0 Dummy )
                    Notch ( 0.844   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Sw 90psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( ALCO/Baldwin Switchers 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.090   0 Dummy )
                    Notch ( 0.185    0 Dummy )
                    Notch ( 0.280   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO_Baldwin Rd Sw 90psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( ALCO/Baldwin Road Switchers 90psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.81 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )



PASSENGER LOCOMOTIVE CONTROLLER/BRAKE_ENGINE  CALIBRATIONS (COMPOSITION BRAKE SHOE EQUIPPED)


EMD 567 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( Passenger EMD 567 110psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


 EMD 645 Turbocharged 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( Passenger EMD 645 Turbocharged 110psi Controller Brake Callibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.045   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )

EMD 710 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


      Comment ( Passenger EMD 710 110psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.063   0 Dummy )
                    Notch ( 0.120    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.340     0 Dummy )
                    Notch ( 0.453  0 Dummy )
                    Notch ( 0.700    0 Dummy )
                    Notch ( 0.860   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


GE Dash-7 and down 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )

     Comment ( GE Dash-7 and down Passenger 110psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.044   0 Dummy )
                    Notch ( 0.114   0 Dummy )
                    Notch ( 0.231   0 Dummy )
                    Notch ( 0.351     0 Dummy )
                    Notch ( 0.511   0 Dummy )
                    Notch ( 0.657    0 Dummy )
                    Notch ( 0.827   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )

Dash-8 and up 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( GE Dash-8 and up Passenger 110psi Controller/Brake Calibrations Composition Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.058   0 Dummy )
                    Notch ( 0.118    0 Dummy )
                    Notch ( 0.265   0 Dummy )
                    Notch ( 0.376     0 Dummy )
                    Notch ( 0.535   0 Dummy )
                    Notch ( 0.686    0 Dummy )
                    Notch ( 0.844   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )

ALCO/Baldwin Passenger Locomotives 110psi Brake Pipe 


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( ALCO/Baldwin Passenger Locomotives 110psi Controller/Brake Calibrations Composition Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.66 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )



FREIGHT LOCOMOTIVE CONTROLLER/BRAKE_ENGINE  CALIBRATIONS (CAST IRON BRAKE SHOE EQUIPPED)

EMD 567 80psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(80 )
	TrainBrakesControllerMaxSystemPressure( 80 )


     Comment ( EMD 567 Freight 80psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.40 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Road Switchers 80psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(80 )
	TrainBrakesControllerMaxSystemPressure( 80 )


     Comment ( ALCO/Baldwin Road Switchers 80psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.40 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )



EMD Switchers 90psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( EMD Switchers 90psi Controller/Brake Calibrations Cast Iron Brake Shoe equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.085   0 Dummy )
                    Notch ( 0.155    0 Dummy )
                    Notch ( 0.260   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


EMD 567 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( EMD 567 Freight 90psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


 GE Switchers 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( GE Switchers 90psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.089   0 Dummy )
                    Notch ( 0.159    0 Dummy )
                    Notch ( 0.260   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


GE Dash-7 and down 90psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( GE Dash-7 and down Freight 90psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.044   0 Dummy )
                    Notch ( 0.114   0 Dummy )
                    Notch ( 0.231   0 Dummy )
                    Notch ( 0.351     0 Dummy )
                    Notch ( 0.511   0 Dummy )
                    Notch ( 0.657    0 Dummy )
                    Notch ( 0.827   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Switchers 90psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( ALCO/Baldwin Switchers 90psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.090   0 Dummy )
                    Notch ( 0.185    0 Dummy )
                    Notch ( 0.280   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Road Switchers 90psi Brake Pipe


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure(90 )
	TrainBrakesControllerMaxSystemPressure( 90 )


     Comment ( ALCO/Baldwin Road Switchers 90psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.42 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


PASSENGER LOCOMOTIVE CONTROLLER/BRAKE_ENGINE  CALIBRATIONS (CAST IRON BRAKE SHOE EQUIPPED)


EMD 567 110psi Brake Pipe

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( Passenger EMD 567 110psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.065   0 Dummy )
                    Notch ( 0.125    0 Dummy )
                    Notch ( 0.250   0 Dummy )
                    Notch ( 0.345     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.38 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


GE Dash-7 and down 110psi Brake Pipe 

	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )



     Comment ( GE Dash-7 and down Passenger 110psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped  )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.044   0 Dummy )
                    Notch ( 0.114   0 Dummy )
                    Notch ( 0.231   0 Dummy )
                    Notch ( 0.351     0 Dummy )
                    Notch ( 0.511   0 Dummy )
                    Notch ( 0.657    0 Dummy )
                    Notch ( 0.827   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.38 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )


ALCO/Baldwin Passenger Locomotives 110psi Brake Pipe 


	EngineBrakesControllerMinSystemPressure( 0 )
	TrainBrakesControllerMinSystemPressure( 0 )
	EngineBrakesControllerMaxSystemPressure( 110 )
	TrainBrakesControllerMaxSystemPressure( 110 )


     Comment ( ALCO/Baldwin Passenger Locomotives 110psi Controller/Brake Calibrations Cast Iron Brake Shoe Equipped )
        EngineControllers (
            Throttle ( 0 1 0.125 0.
                NumNotches ( 9
                    Notch ( 0       0 Dummy )
                    Notch ( 0.072   0 Dummy )
                    Notch ( 0.135    0 Dummy )
                    Notch ( 0.270   0 Dummy )
                    Notch ( 0.378     0 Dummy )
                    Notch ( 0.500   0 Dummy )
                    Notch ( 0.667    0 Dummy )
                    Notch ( 0.855   0 Dummy )
                    Notch ( 1.000       0 Dummy )
                )
            )
            Brake_Engine ( 0 0.38 0.0125 0 
                NumNotches ( 1
                    Notch( 0  1 Dummy )
                )
            )
