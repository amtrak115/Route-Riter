Use this to activate VSFLEX permanently.

1 - Install C1 ActiveX Controls

2 - Unzip the file "C1.7z".

3 - Disconnect internet temporarily, this is so that when registering the license we do not connect to the official server. VERY IMPORTANT!!!

4 - Run the activator as Administrator

5 - Click on "Generate Serial Number" button

6 - Copy the generated serial number and switch to activation tab

7 - Fill in your name, company and the generated serial number.

8 - Select "Automatically over Internet" option

9 - Click "Next" button and wait for some seconds. Done!