
Stand-Alone Installation of Program "TSUtil" (installation-language: english) :

 - Execute installation-program 'TSUtil_EN.exe'
 - Follow all installation-instructions
 - 'Log out' from your workstation and 'log in' again (or 'reboot workstation')


You may start TSUtil by doubleclick on the 'TSUtilDlg'-Icon, which is created during installation-process.
Then a command-window is also created, which can be used to enter more TSUtil-commandlines.

The commandwindow may be enhanced by setting its properties to
	+ Layout windowsize   	: 120
	+ Layout windowheight 	: 40
	+ Layout bufferheight 	: 1000
	+ Options Edit-Options	: 'QuickEdit-Mode' to 'ON'
	+ Options Edit-Options	: 'Insert Mode' to 'ON'
  and save them to the calling association.



ATTENTION:
When you install this programm, you expressly accept the user-license-agreement at the end of
"TSUtil_en.txt", which is included in this file. If you do NOT accept this ageement you must not
install this program or a part of it.
 
Carl-Heinz Rave (carlosHR@t-online.de)


A brief description of the utility is located in file "TSUtil_en.txt"!



ATTENTION: TSUtil may be successfully activated using runtime-version 1.5.0_22 or newer.



